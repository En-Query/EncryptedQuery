package reader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import producer.ProducerGroup;

public class JsonReader {
	
	private static final Logger logger = LoggerFactory.getLogger(JsonReader.class);

	static String ipAddress;
    static String brokers;
	static String topicName;
	static String configFileName;
	static int maxLoadCount;
	static String inputFileName;
	static Properties kafkaProperties;
	static long jsonArrayElements = 0;
	static int queueSize = 10000;
	static int loadRate = 100;
	static String outputType;
	static String outputFileName;
	static BufferedWriter outputFileWriter;
	static ProducerGroup producerGroup;

	static BlockingQueue<String> queue;
	static int numberOfProducers;
	
	private static Properties createProducerConfig(String brokers) {
		Properties props = new Properties();
		props.put("bootstrap.servers", brokers);
		props.put("acks", "all");
		props.put("retries", 0);
		props.put("batch.size", 16384);
		props.put("linger.ms", 1);
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		return props;
	}

	public static void main(String[] args) {

		if (args.length == 0 || args.length > 2) {
			logger.error("Usage JsonReaderKafkaProducer [/path/to/config/file] [/path/to/input/file]");
			return;
		} else {
			initialize(args[0]);
		}

		if (outputType.equalsIgnoreCase("kafka")) {
			kafkaProperties = createProducerConfig(brokers);
			queue = new LinkedBlockingQueue<String>(queueSize);
			producerGroup = new ProducerGroup(kafkaProperties, topicName, queue, maxLoadCount, numberOfProducers);
			producerGroup.execute();

		} else {
			try {
				outputFileWriter = new BufferedWriter(new FileWriter(outputFileName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}
		}

		if (inputFileName == null && args.length > 1) {
			inputFileName = args[1];
		}

		File inputFile = new File(inputFileName);
		if (!inputFile.exists()) {
			logger.error("pcap.input.file ({}) does not exist", inputFileName);
			if (outputType.equalsIgnoreCase("kafka")) {
				producerGroup.stopGroup();
			} else {
				try {
					outputFileWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return;
		}

		logger.info("Reading Json data from: {}", inputFileName);

		InputStream is = null;
		try {
			is = new FileInputStream(new File(inputFileName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return;
		}
		int isEstimatedSize = 0;
		int endCounter = 0;
		JsonObjectIterator joi = new JsonObjectIterator(is);
		while (joi.hasNext()) {
			Map<String, Object> nextElement = new HashMap<String, Object>();
			try {
				nextElement = joi.next();
				String jsonString = new ObjectMapper().writeValueAsString(nextElement);
				if (outputType.equalsIgnoreCase("kafka")) {
					queue.add(jsonString);
					Thread.sleep(loadRate);
				} else {
					outputFileWriter.write(jsonString);
					outputFileWriter.newLine();
				}
				jsonArrayElements++;
				isEstimatedSize = is.available();
				while (isEstimatedSize < 20000) {
                    logger.info("Not enough data for another record, waiting 1 second, data available {}", isEstimatedSize);
					Thread.sleep(1000);
					isEstimatedSize = is.available();
					endCounter++;
					if (endCounter >= 10) {
						break;
					}
				}
			} catch (Exception e) {
				logger.error("Exception {}", e.getMessage());
			}
		}

		try {
			joi.close();
			if (outputType.equalsIgnoreCase("kafka")) {
				long recordsWrittenToKafka = producerGroup.recordsPublished();
				logger.info("Read {} Pcap Packets from json, wrote {} records to kafka topic {}", jsonArrayElements,
						recordsWrittenToKafka, topicName);
				producerGroup.stopGroup();
			} else {
				logger.info("Read {} Pcap Packets from json, wrote {} records to file {}", jsonArrayElements,
						jsonArrayElements, outputFileName);
				outputFileWriter.close();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void initialize(String configFileName) {

		logger.info("Configuration properties file: {}", configFileName);
		File configFile = null;
		configFile = new File(configFileName);
		if (!configFile.exists()) {
			logger.error("Configuration properties file not found " + configFileName);
			GetConfigFile gcf = new GetConfigFile();
			configFile = gcf.getConfigFile(configFileName);
			if (!configFile.exists()) {
				logger.error("Configuration properties file not found in resources folder either");
				return;
			}
		}
		
		SystemConfiguration sysConfig = new SystemConfiguration(configFile.getAbsolutePath());
		
		if (sysConfig.hasProperty("kafka.bootstrap.server")) {
			brokers = sysConfig.getProperty("kafka.bootstrap.server", null);
		} else {
			logger.error("kafka.bootstrap.server missing");
			return;
		}

		if (sysConfig.hasProperty("kafka.topic.name")) {
			topicName = sysConfig.getProperty("kafka.topic.name", "pcap-feed");
		} else {
			logger.error("kafka.topic.name missing");
			return;
		}
		
		outputType = sysConfig.getProperty("output.type", "kafka");
		outputFileName = sysConfig.getProperty("output.file.name", "pcap-data.json");
		
		inputFileName = sysConfig.getProperty("pcap.input.file", null);
		maxLoadCount = sysConfig.getIntProperty("load.record.count",100000);
		loadRate = sysConfig.getIntProperty("load.record.rate", 100);
		numberOfProducers = sysConfig.getIntProperty("number.of.producers", 1);
		queueSize = sysConfig.getIntProperty("queue.size", 10000);
		
		logger.info("Initializion complete");
		logger.info("  maxLoadCount {}", maxLoadCount);
		logger.info("  load rate into Kafka {}", loadRate);
		logger.info("  numberOfProducers {}", numberOfProducers);
		logger.info("  queueSize {}", queueSize);
	}

}

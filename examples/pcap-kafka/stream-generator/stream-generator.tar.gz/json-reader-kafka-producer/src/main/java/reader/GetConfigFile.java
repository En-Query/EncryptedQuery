package reader;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GetConfigFile {
	private static final Logger logger = LoggerFactory.getLogger(GetConfigFile.class);

	ClassLoader classLoader = getClass().getClassLoader();

	public File getConfigFile(String fileName) {
		File configFile = new File(classLoader.getResource(fileName).getFile());
		if (configFile == null) {
			logger.info("config file {} not found", fileName);
		} else {
			logger.info("Config file {} found", configFile.getAbsolutePath());
		}
		return configFile;
	}
}

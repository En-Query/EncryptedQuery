package producer;


import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

public final class ProducerGroup {
	private final int numberOfProducers;

	private List<ProducerThread> producers;
	private List<Thread> producerThreads;
	private AtomicLong recordsPublished = new AtomicLong(0);

	public ProducerGroup(Properties properties, String topic, BlockingQueue<String> queue, long recordCount, int numberOfProducers) {

		this.numberOfProducers = numberOfProducers;

		long producerRecordCount = recordCount / numberOfProducers;
		long extraRecords = recordCount % numberOfProducers;

		producers = new ArrayList<ProducerThread>();
		producerThreads = new ArrayList<Thread>();
		
		for (int i = 0; i < this.numberOfProducers; i++) {
			long newCount = 0;
            if (extraRecords > 0 && i == 0) {
               newCount = producerRecordCount + extraRecords;            	
            } else {
            	newCount = producerRecordCount;
            }
			ProducerThread pThread =
					new ProducerThread(properties, topic, queue, newCount, recordsPublished);
			producers.add(pThread);
		}
	}

	public void execute() {
		for (ProducerThread pThread : producers) {
			Thread t = new Thread(pThread);
			t.start();
			producerThreads.add(t);
		}
	}

	/**
	 * @return the numberOfProducers
	 */
	public int getNumberOfProducers() {
		return numberOfProducers;
	}

	/**
	 * @return the groupId
	 */
	public void stopGroup() {
		for (ProducerThread pThread : producers) {
			pThread.stopThread();
		}
	}
	
	/**
	 * 
	 * @return number of threads still running
	 */
	public int producersRunning() {
		int running = 0;
		  for (Thread thread : producerThreads) {
			  if (thread.isAlive()) {
				  running++;
			  }
		  }
		  
		return running;
	}

    /**
     * 
     * @return number of records published by all threads
     */
	public long recordsPublished() {

		return recordsPublished.get();
		
	}
}
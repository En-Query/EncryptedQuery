package producer;

import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProducerThread implements Runnable {

	private static final Logger logger = LoggerFactory.getLogger(ProducerThread.class);

	private final Properties kafkaProperties;
	private final KafkaProducer<String, String> producer;
	private final String topic;
	private final long numberOfRecordsToGenerate;  // If set to 0, continiously generate records
	private long writeCounter = 0;
	private AtomicBoolean stopThread = new AtomicBoolean(false);
	private AtomicLong recordsProduced;
	
	private BlockingQueue<String> queue;

	public ProducerThread(Properties properties, String topic, BlockingQueue<String> queue, long recordCount, AtomicLong recordsProduced ) {
		logger.info("Initializing Producer Thread");
		this.kafkaProperties  = properties;
		this.producer = new KafkaProducer<String, String>(kafkaProperties);
		this.topic = topic;
		this.numberOfRecordsToGenerate = recordCount;
		this.queue = queue;
		this.recordsProduced = recordsProduced;
	}

	public void stopThread() {
		stopThread.set(true);
	}
	
	public long recordsPublished() {
		return recordsProduced.get();
	}

	public void run() {

		long reportCount = Math.round( numberOfRecordsToGenerate * 0.10 );
		if (numberOfRecordsToGenerate == 0 ) {
			logger.info("Loading tweets until stopped from Thread {}", Thread.currentThread().getId());
		} else {
			logger.info("Loading {} tweets from Thread {}", numberOfRecordsToGenerate, Thread.currentThread().getId());
		}

		while ( ( numberOfRecordsToGenerate == 0 ) || ( writeCounter < numberOfRecordsToGenerate )) {

			String newRecord = null;
			try {
				newRecord = queue.poll(10, TimeUnit.MILLISECONDS);
				if (newRecord != null) {
					ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(topic, newRecord);
					producer.send(producerRecord, new Callback() {

						public void onCompletion(RecordMetadata metadata, Exception e) {
							if (e != null) {
								e.printStackTrace();
								
							}
							//       logger.info("Sent: {}, Partition: {}, Offset: {}", tweet, metadata.partition(), metadata.offset());
						}
					});
					recordsProduced.getAndIncrement();
					writeCounter++;
					if ( ( writeCounter % reportCount == 0 )) {
						logger.info("Loaded {} Records from Thread {}", writeCounter, Thread.currentThread().getId());
					}
				}
			}
			catch (Exception e) {
                logger.error("Exception while publishing tweet to kafka {}", e.getMessage());
                logger.error("Original Tweet to be published {}", newRecord);
			}
			if (stopThread.compareAndSet(true, false)) {
				logger.info("Stop Issued to thread {}", Thread.currentThread().getName());
				break;
			}
		}
		producer.close();
		logger.info("Kafka Producer Thread {} has stopped after writing {} records", Thread.currentThread().getId(), writeCounter);

	}
}

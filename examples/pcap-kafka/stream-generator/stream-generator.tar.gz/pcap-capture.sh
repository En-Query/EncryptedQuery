#!/bin/bash
##Setup and capture pcap data using wiresharks tshark command line utility.  
##sending the data in json format to an output file.
## command line  ./pcap-capture.sh any 30 ""
## the above will capture data from any interface for 30 seconds with no filter.
set -o xtrace
OUTPUTFILE=output/new-pcap-data.json
INTERFACE=$1
DURATION=$2
FILTER=$3
echo "Capture Pcap Data on Interface $INTERFACE."
echo "For $DURATION seconds."
echo "Capture Filter $FILTER."
## Start the pcap listening
tshark -i $INTERFACE -f "$FILTER" -T json -a duration:$DURATION > $OUTPUTFILE &
## Wait for 10 seconds to get data built up in the output file then start the java app 
## that will read from the file and import it into kafka
sleep 10
java -jar json-reader-kafka-producer-0.0.1-SNAPSHOT-jar-with-dependencies.jar json-reader.properties $OUTPUTFILE

